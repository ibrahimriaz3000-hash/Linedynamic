package com.dynamicpill.module;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.DisplayCutout;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;

/** Adds the pill as an always-on overlay window inside the System UI process. */
public class PillController {
    static final String MODULE_PKG = "com.dynamicpill.module";
    static final String PREF_FILE = "pill_prefs";
    static final String K_ENABLED = "enabled";
    static final String K_WIDTH = "width_mm10";     // 0.1 mm units
    static final String K_HEIGHT = "height_mm10";   // 0.1 mm units
    static final String K_YOFF = "yoff_mm10";       // 0.1 mm units, can be negative
    static final String K_ALPHA = "alpha_pct";
    // iOS style line (grabber) under the status bar
    static final String K_LINE_ON = "line_on";
    static final String K_LINE_W = "line_w2_mm10";
    static final String K_LINE_H = "line_h_mm10";
    static final String K_LINE_X = "line_right_mm10"; // distance from right edge to line CENTER
    static final String K_LINE_Y = "line_top_mm10";   // distance from top of screen
    static final String K_LINE_ALPHA = "line_alpha_pct";
    static final String K_LINE_SMART = "line_smart_hide";
    static final String K_LINE_LOCK = "line_show_lock";
    static final String K_LINE_HOME = "line_show_home";
    static final int D_LINE_W = 160, D_LINE_X = 125, D_LINE_Y = 69;
    static final String K_BORDER = "border_mm10"; // 0 = off
    static final String K_LOCK = "show_lock";
    static final String K_PAD_L = "pad_l_mm10";
    static final String K_PAD_R = "pad_r_mm10";
    static final String K_PAD_T = "pad_t_mm10";
    static final int D_WIDTH = 135;                  // 13.5 mm
    static final int D_HEIGHT = 40;                  // 4.0 mm
    static final int D_YOFF = 0;

    private static java.lang.ref.WeakReference<View> barContents, barRoot;
    private static int[] origContents, origRoot;
    // Top padding = extra status bar height (so icons move down instead of getting squashed/clipped)
    private static volatile int extraTop = 0;
    private static final java.util.HashMap<Integer, Boolean> heightIds = new java.util.HashMap<>();
    private static java.lang.ref.WeakReference<Object> sbWindowController;

    private static boolean isBarHeightId(android.content.res.Resources r, int id) {
        if (id == 0) return false;
        synchronized (heightIds) {
            Boolean b = heightIds.get(id);
            if (b != null) return b;
        }
        boolean m = false;
        try {
            String n = r.getResourceEntryName(id);
            m = "status_bar_height".equals(n) || "status_bar_height_portrait".equals(n)
                    || "status_bar_height_landscape".equals(n) || "status_bar_height_default".equals(n);
        } catch (Throwable ignored) { }
        synchronized (heightIds) { heightIds.put(id, m); }
        return m;
    }

    /** Makes the status bar taller by the "Top" padding value. */
    static void hookStatusBarHeight(ClassLoader cl) {
        de.robv.android.xposed.XC_MethodHook h = new de.robv.android.xposed.XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                int extra = extraTop;
                if (extra <= 0) return;
                try {
                    if (!isBarHeightId((android.content.res.Resources) param.thisObject,
                            (Integer) param.args[0])) return;
                    Object res = param.getResult();
                    if (res instanceof Integer) param.setResult((Integer) res + extra);
                    else if (res instanceof Float) param.setResult((Float) res + extra);
                } catch (Throwable ignored) { }
            }
        };
        de.robv.android.xposed.XposedHelpers.findAndHookMethod(
                android.content.res.Resources.class, "getDimensionPixelSize", int.class, h);
        de.robv.android.xposed.XposedHelpers.findAndHookMethod(
                android.content.res.Resources.class, "getDimensionPixelOffset", int.class, h);
        de.robv.android.xposed.XposedHelpers.findAndHookMethod(
                android.content.res.Resources.class, "getDimension", int.class, h);

        Class<?> c = de.robv.android.xposed.XposedHelpers.findClassIfExists(
                "com.android.systemui.statusbar.window.StatusBarWindowController", cl);
        if (c != null) {
            XposedBridge.hookAllConstructors(c, new de.robv.android.xposed.XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    sbWindowController = new java.lang.ref.WeakReference<>(param.thisObject);
                }
            });
        }
    }

    private void refreshBarHeight() {
        Object o = sbWindowController == null ? null : sbWindowController.get();
        if (o == null) return;
        try {
            de.robv.android.xposed.XposedHelpers.callMethod(o, "refreshStatusBarHeight");
        } catch (Throwable ignored) { }
    }

    private static java.lang.ref.WeakReference<android.view.ViewGroup> kgBar;
    private static java.lang.ref.WeakReference<Object> kgManager;

    /** Keyguard (lock screen) status bar view: the line lives inside it, so it only shows on the lock screen. */
    static void registerKeyguardBar(View v) {
        // Disabled: hosting the line inside the keyguard view made it invisible on some ROMs.
        // The overlay window is used instead (see updateLine).
    }

    /** Captures the keyguard view manager so we can ask whether the PIN/pattern screen is showing. */
    static void hookKeyguardManager(ClassLoader cl) {
        Class<?> c = de.robv.android.xposed.XposedHelpers.findClassIfExists(
                "com.android.systemui.statusbar.phone.StatusBarKeyguardViewManager", cl);
        if (c == null) return;
        XposedBridge.hookAllConstructors(c, new de.robv.android.xposed.XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                kgManager = new java.lang.ref.WeakReference<>(param.thisObject);
            }
        });
    }

    private static java.lang.ref.WeakReference<Object> sbState;

    static void hookStatusBarState(ClassLoader cl) {
        Class<?> c = de.robv.android.xposed.XposedHelpers.findClassIfExists(
                "com.android.systemui.statusbar.StatusBarStateControllerImpl", cl);
        if (c == null) return;
        XposedBridge.hookAllConstructors(c, new de.robv.android.xposed.XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                sbState = new java.lang.ref.WeakReference<>(param.thisObject);
            }
        });
    }

    /** AOSP states: 0 = shade (unlocked), 1 = keyguard, 2 = shade over keyguard. */
    private int barState() {
        Object o = sbState == null ? null : sbState.get();
        if (o == null) return -1;
        try {
            Object r = de.robv.android.xposed.XposedHelpers.callMethod(o, "getState");
            if (r instanceof Integer) return (Integer) r;
        } catch (Throwable ignored) { }
        return -1;
    }

    private static java.lang.ref.WeakReference<Object> shadeWin;

    static void hookShadeWindow(ClassLoader cl) {
        String[] names = {
                "com.android.systemui.statusbar.NotificationShadeWindowControllerImpl",
                "com.android.systemui.statusbar.phone.NotificationShadeWindowControllerImpl"
        };
        for (String n : names) {
            Class<?> c = de.robv.android.xposed.XposedHelpers.findClassIfExists(n, cl);
            if (c == null) continue;
            XposedBridge.hookAllConstructors(c, new de.robv.android.xposed.XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    shadeWin = new java.lang.ref.WeakReference<>(param.thisObject);
                }
            });
        }
    }

    private Boolean pollBool(java.lang.ref.WeakReference<Object> ref, String name) {
        Object o = ref == null ? null : ref.get();
        if (o == null) return null;
        try {
            Object r = de.robv.android.xposed.XposedHelpers.callMethod(o, name);
            if (r instanceof Boolean) return (Boolean) r;
        } catch (Throwable ignored) { }
        return null;
    }

    /** True while the notification shade / Control Center is pulled down (best effort). */
    private boolean panelExpanded() {
        Boolean a = pollBool(sbState, "isExpanded");
        Boolean b = pollBool(shadeWin, "getPanelExpanded");
        Boolean c = pollBool(shadeWin, "isPanelExpanded");
        return (a != null && a) || (b != null && b) || (c != null && c);
    }

    private String homePkg = null;
    private long lastHomePkgCheck = 0, lastHomeCheck = 0;
    private boolean cachedHome = true;

    /** True when the launcher (home screen) is the top app. If it cannot be detected, assume true. */
    private boolean isHomeForeground() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastHomeCheck < 600) return cachedHome;
        lastHomeCheck = now;
        try {
            if (homePkg == null || now - lastHomePkgCheck > 30000) {
                lastHomePkgCheck = now;
                android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_MAIN)
                        .addCategory(android.content.Intent.CATEGORY_HOME);
                android.content.pm.ResolveInfo ri = ctx.getPackageManager()
                        .resolveActivity(i, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY);
                homePkg = (ri != null && ri.activityInfo != null) ? ri.activityInfo.packageName : null;
            }
            android.app.ActivityManager am = (android.app.ActivityManager)
                    ctx.getSystemService(Context.ACTIVITY_SERVICE);
            @SuppressWarnings("deprecation")
            java.util.List<android.app.ActivityManager.RunningTaskInfo> t = am.getRunningTasks(1);
            if (t != null && !t.isEmpty() && t.get(0).topActivity != null && homePkg != null) {
                cachedHome = homePkg.equals(t.get(0).topActivity.getPackageName());
            } else {
                cachedHome = true;
            }
        } catch (Throwable e) {
            cachedHome = true;
        }
        return cachedHome;
    }

    private String lastLineLog = "";

    private boolean bouncerShowing() {
        Object o = kgManager == null ? null : kgManager.get();
        if (o == null) return false;
        String[] names = {"isBouncerShowing", "primaryBouncerIsShowing",
                "isPrimaryBouncerShowing", "bouncerIsShowing"};
        for (String n : names) {
            try {
                Object r = de.robv.android.xposed.XposedHelpers.callMethod(o, n);
                if (r instanceof Boolean) return (Boolean) r;
            } catch (Throwable ignored) { }
        }
        return false;
    }

    static void registerBar(View v, boolean contents) {
        int[] o = {v.getPaddingLeft(), v.getPaddingTop(), v.getPaddingRight(), v.getPaddingBottom()};
        if (contents) { barContents = new java.lang.ref.WeakReference<>(v); origContents = o; }
        else { barRoot = new java.lang.ref.WeakReference<>(v); origRoot = o; }
    }

    private void applyBarPadding() {
        View v = null; int[] o = null;
        if (barContents != null && barContents.get() != null) { v = barContents.get(); o = origContents; }
        else if (barRoot != null && barRoot.get() != null) { v = barRoot.get(); o = origRoot; }
        if (v == null || o == null) return;
        int l = o[0] + mm(pref(K_PAD_L, 0));
        int t = o[1] + mm(pref(K_PAD_T, 0));
        int r = o[2] + mm(pref(K_PAD_R, 0));
        if (v.getPaddingLeft() != l || v.getPaddingTop() != t || v.getPaddingRight() != r) {
            v.setPadding(l, t, r, o[3]);
        }
    }

    private final Context ctx;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final WindowManager wm;
    private XSharedPreferences xsp;
    private PillView view;
    private LineView lineView;
    private LineView hostedLine;
    private boolean lineAdded = false;
    private boolean lastLineVisible = true;
    private int lastLW = -1, lastLH = -1, lastLX = Integer.MIN_VALUE, lastLY = Integer.MIN_VALUE;
    private boolean added = false;
    private int lastW = -1, lastH = -1, lastY = Integer.MIN_VALUE;
    private boolean lastVisible = true;
    private int winType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
    // lockscreen ke upar dikhne wale system window types (pehle wala chalega jo allow ho)
    private static final int[] TYPES = {
            2017, // TYPE_STATUS_BAR_SUB_PANEL
            2024, // TYPE_NAVIGATION_BAR_PANEL
            2038  // TYPE_APPLICATION_OVERLAY (fallback)
    };

    public PillController(Context ctx) {
        this.ctx = ctx;
        this.wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
    }

    public void start() {
        try {
            xsp = new XSharedPreferences(MODULE_PKG, PREF_FILE);
            xsp.makeWorldReadable();
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: prefs init: " + t);
        }
        try { extraTop = mm(pref(K_PAD_T, 0)); } catch (Throwable ignored) { }
        // small delay so System UI finishes booting
        handler.postDelayed(tick, 4000);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            try {
                update();
            } catch (Throwable t) {
                XposedBridge.log("DynamicPill: update failed: " + t);
            }
            handler.postDelayed(this, 400);
        }
    };

    private int pref(String key, int def) {
        try {
            if (xsp != null) return xsp.getInt(key, def);
        } catch (Throwable ignored) { }
        return def;
    }

    private boolean prefBool(String key, boolean def) {
        try {
            if (xsp != null) return xsp.getBoolean(key, def);
        } catch (Throwable ignored) { }
        return def;
    }

    private int mm(float mm10) {
        DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_MM, mm10 / 10f, dm));
    }

    private int cutoutCenterY() {
        try {
            DisplayCutout dc = wm.getCurrentWindowMetrics().getWindowInsets().getDisplayCutout();
            if (dc != null) {
                Rect r = dc.getBoundingRectTop();
                if (r != null && !r.isEmpty()) return (r.top + r.bottom) / 2;
            }
        } catch (Throwable ignored) { }
        try {
            int id = ctx.getResources().getIdentifier("status_bar_height", "dimen", "android");
            if (id > 0) return ctx.getResources().getDimensionPixelSize(id) / 2;
        } catch (Throwable ignored) { }
        return mm(30);
    }

    private void update() {
        if (xsp != null && xsp.hasFileChanged()) xsp.reload();

        try {
            int e = mm(pref(K_PAD_T, 0));
            if (e != extraTop) {
                extraTop = e;
                refreshBarHeight();
            }
        } catch (Throwable ignored) { }
        try { applyBarPadding(); } catch (Throwable ignored) { }

        boolean enabled = prefBool(K_ENABLED, true);
        boolean portrait = ctx.getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_PORTRAIT;
        boolean locked = false;
        try {
            android.app.KeyguardManager km = (android.app.KeyguardManager)
                    ctx.getSystemService(Context.KEYGUARD_SERVICE);
            locked = km != null && km.isKeyguardLocked();
        } catch (Throwable ignored) { }
        boolean visible = enabled && portrait && (!locked || prefBool(K_LOCK, true));

        int w = mm(pref(K_WIDTH, D_WIDTH));
        int h = mm(pref(K_HEIGHT, D_HEIGHT));
        int y = cutoutCenterY() - h / 2 + mm(pref(K_YOFF, D_YOFF));

        if (!added) {
            view = new PillView(ctx);
            for (int type : TYPES) {
                try {
                    wm.addView(view, params(w, h, y, type));
                    winType = type;
                    added = true;
                    break;
                } catch (Throwable t) {
                    XposedBridge.log("DynamicPill: window type " + type + " failed: " + t);
                    view = new PillView(ctx);
                }
            }
            if (!added) return;
            lastW = w; lastH = h; lastY = y;
        } else if (w != lastW || h != lastH || y != lastY) {
            wm.updateViewLayout(view, params(w, h, y, winType));
            lastW = w; lastH = h; lastY = y;
        }

        try { view.setPillAlpha(pref(K_ALPHA, 100)); } catch (Throwable ignored) { }
        try { view.setBorder(mm(pref(K_BORDER, 4))); } catch (Throwable ignored) { }

        if (visible != lastVisible) {
            view.setVisibility(visible ? View.VISIBLE : View.GONE);
            lastVisible = visible;
        }

        try {
            updateLine(portrait, locked);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: line failed: " + t);
        }
    }

    private void updateLine(boolean portrait, boolean locked) {
        boolean smart = prefBool(K_LINE_SMART, true);
        boolean bouncer = smart && bouncerShowing();
        int st = smart ? barState() : -1;
        boolean expanded = smart && panelExpanded();
        boolean showLock = prefBool(K_LINE_LOCK, true) && locked && !bouncer && st != 2;
        boolean showHome = prefBool(K_LINE_HOME, true) && !locked && !expanded && isHomeForeground();
        boolean on = prefBool(K_LINE_ON, true) && portrait && (showLock || showHome);
        String why = "on=" + on + " locked=" + locked + " bouncer=" + bouncer
                + " state=" + st + " expanded=" + expanded + " home=" + cachedHome;
        if (!why.equals(lastLineLog)) {
            lastLineLog = why;
            XposedBridge.log("DynamicPill: line " + why);
        }
        int w = mm(pref(K_LINE_W, D_LINE_W));
        int h = Math.max(1, mm(pref(K_LINE_H, 6)));
        int fromRight = mm(pref(K_LINE_X, D_LINE_X));
        int top = mm(pref(K_LINE_Y, D_LINE_Y));
        int alpha = pref(K_LINE_ALPHA, 70);

        android.view.ViewGroup host = kgBar == null ? null : kgBar.get();
        boolean hosted = false;
        if (host != null && host.isAttachedToWindow()) {
            try {
                hosted = updateHostedLine(host, on, w, h, fromRight, top, alpha);
            } catch (Throwable t) {
                XposedBridge.log("DynamicPill: hosted line failed: " + t);
                detachHosted();
            }
        } else {
            detachHosted();
        }

        if (hosted) {
            if (lineAdded && lastLineVisible) {
                lineView.setVisibility(View.GONE);
                lastLineVisible = false;
            }
            return;
        }

        // fallback: overlay window, only while the phone is locked
        boolean vis = on;
        int x = Math.max(0, fromRight - w / 2);
        if (!lineAdded) {
            lineView = new LineView(ctx);
            wm.addView(lineView, lineParams(w, h, x, top, winType));
            lineAdded = true;
            lastLW = w; lastLH = h; lastLX = x; lastLY = top;
            lineView.setVisibility(vis ? View.VISIBLE : View.GONE);
            lastLineVisible = vis;
        } else if (w != lastLW || h != lastLH || x != lastLX || top != lastLY) {
            wm.updateViewLayout(lineView, lineParams(w, h, x, top, winType));
            lastLW = w; lastLH = h; lastLX = x; lastLY = top;
        }
        lineView.setLineAlpha(alpha);
        if (vis != lastLineVisible) {
            lineView.setVisibility(vis ? View.VISIBLE : View.GONE);
            lastLineVisible = vis;
        }
    }

    private boolean updateHostedLine(android.view.ViewGroup host, boolean on, int w, int h,
                                     int fromRight, int top, int alpha) {
        if (hostedLine == null || hostedLine.getParent() != host) {
            detachHosted();
            hostedLine = new LineView(ctx);
            host.addView(hostedLine, new android.view.ViewGroup.MarginLayoutParams(w, h));
            // let the line draw below the status bar even if the header is short
            View c = host;
            for (int i = 0; i < 5; i++) {
                if (c instanceof android.view.ViewGroup) {
                    ((android.view.ViewGroup) c).setClipChildren(false);
                    ((android.view.ViewGroup) c).setClipToPadding(false);
                }
                if (c.getParent() instanceof View) c = (View) c.getParent(); else break;
            }
        }
        android.view.ViewGroup.LayoutParams lp = hostedLine.getLayoutParams();
        if (lp.width != w || lp.height != h) {
            lp.width = w;
            lp.height = h;
            hostedLine.setLayoutParams(lp);
        }
        int offX = 0, offY = 0;
        View c = host;
        while (true) {
            offX += c.getLeft();
            offY += c.getTop();
            if (c.getParent() instanceof View) c = (View) c.getParent(); else break;
        }
        float targetLeft = screenWidth() - fromRight - w / 2f;
        hostedLine.setTranslationX(targetLeft - offX);
        hostedLine.setTranslationY(top - offY);
        hostedLine.setLineAlpha(alpha);
        hostedLine.setVisibility(on ? View.VISIBLE : View.GONE);
        return true;
    }

    private void detachHosted() {
        if (hostedLine != null) {
            try {
                if (hostedLine.getParent() instanceof android.view.ViewGroup) {
                    ((android.view.ViewGroup) hostedLine.getParent()).removeView(hostedLine);
                }
            } catch (Throwable ignored) { }
            hostedLine = null;
        }
    }

    private int screenWidth() {
        return wm.getCurrentWindowMetrics().getBounds().width();
    }

    private WindowManager.LayoutParams lineParams(int w, int h, int x, int y, int type) {
        WindowManager.LayoutParams lp = params(w, h, y, type);
        lp.gravity = Gravity.TOP | Gravity.END;   // x = distance from the right edge
        lp.x = x;
        lp.setTitle("DynamicPillLine");
        return lp;
    }

    private WindowManager.LayoutParams params(int w, int h, int y, int type) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                w, h,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.x = 0;
        lp.y = y;
        lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        lp.alpha = 1.0f; // window alpha poora solid
        lp.setTitle("DynamicPill");
        return lp;
    }
}
